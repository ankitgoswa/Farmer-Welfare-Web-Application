const chatbox = document.getElementById("chatbox");
const input = document.getElementById("userInput");
let selectedLang = "";

const replies = {
  en: {
    welcome: "Welcome! Please choose a language: English or Hindi.",
    set: "Language set to English. Ask your question.",
    fertilizer: "You can book fertilizer from the Fertilizer Booking page.",
    schemes: "Visit the Schemes section for all government schemes.",
    documents: "You can save your documents in the Document Locker.",
    default: "Sorry, I didn't understand. Please try again.",
  },
  hi: {
    welcome: "स्वागत है! कृपया भाषा चुनें: English या Hindi।",
    set: "भाषा हिन्दी सेट हो गई है। अब आप सवाल पूछें।",
    fertilizer: "आप खाद 'Fertilizer Booking' पेज से बुक कर सकते हैं।",
    schemes: "सरकारी योजनाओं के लिए 'Schemes' सेक्शन पर जाएं।",
    documents: "आप 'Document Locker' में अपने दस्तावेज़ सेव कर सकते हैं।",
    default: "माफ कीजिए, मैं समझ नहीं पाया। कृपया दोबारा पूछें।",
  },
};

append("🤖 " + replies.en.welcome); // First message in English

function append(msg) {
  chatbox.innerHTML += `<div>${msg}</div>`;
  chatbox.scrollTop = chatbox.scrollHeight;
}

function getResponse() {
  const msg = input.value.trim();
  append("🧑‍💬 " + msg);

  if (!selectedLang) {
    if (/hindi/i.test(msg)) selectedLang = "hi";
    else if (/english/i.test(msg)) selectedLang = "en";

    if (selectedLang) append("🤖 " + replies[selectedLang].set);
    else append("🤖 Please type 'English' or 'Hindi' to choose language.");
    input.value = "";
    return;
  }

  const r = replies[selectedLang];
  let response = r.default;

  if (/fertilizer|खाद/i.test(msg)) response = r.fertilizer;
  else if (/scheme|योजना/i.test(msg)) response = r.schemes;
  else if (/document|दस्तावेज़/i.test(msg)) response = r.documents;

  append("🤖 " + response);
  input.value = "";
}
