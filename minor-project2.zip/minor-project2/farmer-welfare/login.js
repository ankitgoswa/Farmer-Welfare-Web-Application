document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;


    if (username === "farmer" && password === "1234") {
    document.getElementById("message").innerText = "Login successful!";
   
  } else {
    document.getElementById("message").innerText = "Invalid credentials!";
  }
});
