let map;
let markers = [];
let stalls = [
  {
    id: 1,
    name: "Green Agri Stall",
    lat: 28.7041,
    lng: 77.1025,
    fertilizer: ["Urea", "DAP"],
  },
  {
    id: 2,
    name: "Farmer's Choice",
    lat: 28.705,
    lng: 77.108,
    fertilizer: ["Potash", "Urea"],
  },
];

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 28.7041, lng: 77.1025 },
    zoom: 13,
  });
  displayStalls(stalls);
}

function displayStalls(data) {
  clearMarkers();
  data.forEach((stall) => {
    const marker = new google.maps.Marker({
      position: { lat: stall.lat, lng: stall.lng },
      map,
      title: stall.name,
    });

    marker.addListener("click", () => {
      document.getElementById("selected-stall").value = stall.name;
      alert(`Stall Selected: ${stall.name}`);
    });

    markers.push(marker);
  });
}

function filterStalls() {
  const selectedType = document.getElementById("fertilizer-type").value;
  const filtered = stalls.filter((stall) =>
    stall.fertilizer.includes(selectedType)
  );
  displayStalls(filtered);
}

function clearMarkers() {
  for (let m of markers) {
    m.setMap(null);
  }
  markers = [];
}

document
  .getElementById("booking-form")
  .addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    const booking = {};
    formData.forEach((value, key) => (booking[key] = value));
    alert(`Booking Successful!\n${JSON.stringify(booking, null, 2)}`);
    localStorage.setItem(`booking-${Date.now()}`, JSON.stringify(booking));
    this.reset();
  });

document.getElementById("land-size").addEventListener("input", function () {
  const landSize = parseInt(this.value);
  const quantityInput = document.getElementById("quantity");
  if (!isNaN(landSize) && landSize > 0) {
    quantityInput.value = landSize; // 1 bori per acre
  } else {
    quantityInput.value = "";
  }
});

document
  .getElementById("booking-form")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const form = this;
    const landSize = parseInt(form.landSize.value);
    const quantity = parseInt(form.quantity.value);
    const khasra = form.khasra.value.trim();
    const landRecord = form.landRecord.files[0];

    if (!landSize || !quantity || quantity !== landSize) {
      alert("Quantity should match land size (1 bori per acre).");
      return;
    }

    if (!khasra) {
      alert("Please enter your Khasra Number.");
      return;
    }

    if (!landRecord || landRecord.type !== "application/pdf") {
      alert("Please upload a valid PDF land record.");
      return;
    }

    const booking = {
      fertilizer: form.fertilizer.value,
      landSize,
      quantity,
      khasra,
      landRecordName: landRecord.name,
      date: form.date.value,
      time: form.time.value,
      stall: form.stall.value,
    };

    alert(`✅ Booking Successful!\n${JSON.stringify(booking, null, 2)}`);
    localStorage.setItem(`booking-${Date.now()}`, JSON.stringify(booking));
    form.reset();
    document.getElementById("quantity").value = "";
  });

// Sample fertilizer warehouse data (Name + Lat + Lon)
const warehouses = [
  { name: "Krishi Kendra A", lat: 26.9124, lon: 75.7873 },
  { name: "Krishi Kendra B", lat: 26.92, lon: 75.8 },
  { name: "Fertilizer Depot C", lat: 26.905, lon: 75.78 },
];

function getLocationAndNearbyStalls() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLat = position.coords.latitude;
        const userLon = position.coords.longitude;

        const sortedWarehouses = warehouses
          .map((wh) => {
            const distance = getDistance(userLat, userLon, wh.lat, wh.lon);
            return { ...wh, distance };
          })
          .sort((a, b) => a.distance - b.distance);

        populateStallDropdown(sortedWarehouses);
      },
      () => {
        alert("Location access denied. Please allow it to find nearby stalls.");
      }
    );
  } else {
    alert("Geolocation not supported by your browser.");
  }
}

// Haversine formula to calculate distance in KM
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return +(R * c).toFixed(2);
}

function deg2rad(deg) {
  return deg * (Math.PI / 180);
}

// Fill dropdown with sorted nearest stalls
function populateStallDropdown(stalls) {
  const dropdown = document.getElementById("stall-dropdown");
  dropdown.innerHTML = '<option value="">Select a nearby stall</option>';
  stalls.forEach((stall) => {
    const option = document.createElement("option");
    option.value = stall.name;
    option.textContent = `${stall.name} – ${stall.distance} km`;
    dropdown.appendChild(option);
  });
}
